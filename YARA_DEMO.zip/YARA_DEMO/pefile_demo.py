import pefile
pe = pefile.PE("wannacry.exe")
print("e_magic : " + hex(pe.DOS_HEADER.e_magic)) # Prints the e_magic field of the DOS_HEADER
