import os
import subprocess
import sys

if len(sys.argv) == 2:
	output = subprocess.check_output('yara -s KKNPP_Dtrack_check '+sys.argv[1],shell=True)

	output1 = output.split('\n')

	if len(output1) > 7:
		print "============================="
		print "KKNPP_Dtrack Malware detected"
		print "============================="
		for i in range(0,len(output1)-6):
			if i == 1:
				print "\nMatching Strings"
				print "==================="
			print output1[i]

	else:
		print "============================="
		print "Not a KKNPP_Dtrack Malware"
		print "============================="

else:
	print "Please run below command"
	print "python "+sys.argv[0]+" Complete_file_path"
