import os
import subprocess
import sys

if len(sys.argv) == 2 :

	output = subprocess.check_output('yara -s pdf_EXE_check '+sys.argv[1],shell=True)

	output1 = output.split('\n')

	#print output1
	if len(output1) > 7 and output1[0].find('IsPE') != -1:
		print "============================="
		print "EXE file detected"
		print "============================="
		print output1[0]

	elif len(output1) > 7 and output1[0].find('IsPDF') != -1:
		print "============================="
		print "PDF file detected"
		print "============================="
		print output1[0]

	else:
		print "============================="
		print "NO PDF and EXE file detected"
		print "============================="

else:
	print "Please run below command"
	print "python "+sys.argv[0]+" Complete_file_path"
